import java.awt.*;
import java.awt.image.*;
import ij.*;
import ij.gui.*;
import ij.process.*;
import ij.plugin.PlugIn;
import ij.io.*;
import java.io.*;
import ij.plugin.*;

// G. Landini at bham.ac.uk
// 28 Dec 2003
// 5 Jan 2006 various improvements
// Makes an RGB stack of LUTs

public class List_LUTs implements PlugIn {

	public void run(String arg) {

		GenericDialog gd = new GenericDialog("List LUTs", IJ.getInstance());
		gd.addMessage("List all LUT files");
		gd.addCheckbox("Include names",false);

		gd.showDialog();
		if (gd.wasCanceled())
			return;


		boolean names = gd.getNextBoolean ();
		boolean isLinux=false;
		//IJ.showStatus("Select a folder with LUTs...");
//LookUpTable lut;
		byte[] r = new byte[256];
		byte[] g = new byte[256];
		byte[] b = new byte[256];

		int w = 256, h, x, y, i, j;
		OpenDialog od = new OpenDialog("Select any file in LUTs folder...", null);
		if (names)
			h=40;
		else
			h=24;
		String dir = od.getDirectory();
		String name = od.getFileName();
		if (name==null)
			return;

		String[] list = new File(dir).list();

		java.util.Arrays.sort(list);
		if (System.getProperty("os.name").startsWith("Linux"))
			isLinux=true;
		for (i=0; i<list.length; i++) {

			//if(list[i].endsWith(".lut") || list[i].endsWith(".map") ){
			if(list[i].endsWith(".lut")) {

				//IJ.log(i+": "+list[i]);
				IJ.showStatus("Opening "+(i+1)+": "+list[i]);

				ImagePlus imp = NewImage.createByteImage(list[i], w, h, 1, 0);
				ImageProcessor ip = imp.getProcessor();
				byte[] pixels = (byte[])ip.getPixels();
				imp.show();
				j=0;
				for (y = 0; y < h; y++) {
					for (x = 0; x < w; x++) {
						pixels[j++] = (byte) x;
					}
				}

				imp.updateAndDraw();
				//IJ.run("LUT... ", "path='"+dir+list[i]+"'");
				IJ.open(dir+list[i]);

				IndexColorModel icm = (IndexColorModel)imp.getProcessor().getColorModel();
				icm.getReds(r);
				icm.getGreens(g);
				icm.getBlues(b);
				for(int k=0;k<256;k++){
					String metadata =""+(r[k]&0xff)+" "+(g[k]&0xff)+" "+(b[k]&0xff)+" ";
					imp.setProperty("Info", k<1?metadata:imp.getProperty("Info")+metadata);
					//IJ.log((r[k]&0xff)+" "+(g[k]&0xff)+" "+(b[k]&0xff));
				}

				if (isLinux) 
					IJ.wait(250); // odd bug which allows changing to RGB type before the lut is applied
				IJ.run("RGB Color");
				if (names){
					ImagePlus imp2 = WindowManager.getCurrentImage();
					ImageProcessor ip2 = imp.getProcessor();
					for (y = 0; y < 16; y++) {
						for (x = 0; x < w; x++) {
							ip2.putPixel(x,y,(int)((255 & 0xff) <<16)+ ((255 & 0xff) << 8) + (255 & 0xff));
						}
					}
					ip2.setFont(new Font("Monospaced", Font.PLAIN, 12));
					ip2.setAntialiasedText(true);
					ip2.setColor(Color.black);
					ip2.moveTo(8,16);
					ip2.drawString(list[i]);
					imp2.updateAndDraw();
				}
			}
		}
		IJ.showStatus("Creating stack...");
		IJ.run("Convert Images to Stack");
		String sdir = IJ.getDirectory("plugins");
		IJ.saveAs("Tiff", sdir+"LUTs.tif");
	}
}
