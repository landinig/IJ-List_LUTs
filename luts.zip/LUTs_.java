import ij.plugin.*;
import ij.*;
import ij.gui.*;
import ij.process.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.StringTokenizer;

/**
  Loads LUTs which are stored in a stack (made with the List_LUTs plugin)
  Based on PanelWindow.java
  G.Landini at bham ac uk
  Thanks to Wayne Rasband for implementing the ImageListener
  31/12/2005
  01/08/2006
*/

public class LUTs_ implements PlugIn {

	static String dir = IJ.getDirectory("plugins");

	public void run(String arg) {
		if (IJ.versionLessThan("1.35l")) return;

		IJ.open(dir+"LUTs.tif");
		ImagePlus imp = WindowManager.getCurrentImage();


		if (imp==null) {
			IJ.error("No Look Up Table file found!\n\"/plugins/LUTs.tif\" is missing.");
			return;
		}
		if (imp.getStackSize()==1){
			IJ.error("The LUTs.tif file must have more than 1 slice");
			return;
		}
		CustomCanvas cc = new CustomCanvas(imp);
		new CustomStackWindow(imp, cc);

	}


	class CustomCanvas extends ImageCanvas {
		CustomCanvas(ImagePlus imp) {
			super(imp);
		}
	} // CustomCanvas inner class


    class CustomStackWindow extends StackWindow implements ActionListener, ImageListener {
		private Button button1;
		private List list;
		private int [] wList;
		private ImagePlus customImp;

		CustomStackWindow(ImagePlus imp, ImageCanvas ic) {
			super(imp, ic);
			addPanel();
			ImagePlus.addImageListener(this);
			//IJ.log("Adding listener");
			customImp = imp;
		}

		void addPanel() {
			Panel panel = new Panel();
			button1 = new Button(" Apply ");
			button1.addActionListener(this);
			panel.add(button1);

			list = new List(6);
			wList = WindowManager.getIDList();
			for (int i=0; i<wList.length; i++) {
				ImagePlus imp = WindowManager.getImage(wList[i]);
				//if (imp!=null && (imp.getType()<3)) //only greycale
				if (imp!=null && !(imp.getTitle().equals("LUTs.tif")))
					list.add(imp.getTitle());
			}
			list.addActionListener(this);
			panel.add(list);
			add(panel);
			pack();

			Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
			Point loc = getLocation();
			Dimension size = getSize();
			if (loc.y+size.height>screen.height)
				getCanvas().zoomOut(0, 0);
		}


		public void imageOpened(ImagePlus imp) {
			//IJ.log(imp.getTitle() + " opened");
			list.add(imp.getTitle());
		}

		public void imageClosed(ImagePlus imp) {
			//IJ.log(imp.getTitle() + " closed");
			if (imp==customImp) {
				//IJ.log("Removing listener");
				ImagePlus.removeImageListener(this);
			} else
				list.remove(imp.getTitle());
		}

		public void imageUpdated(ImagePlus imp) {
			//IJ.log(imp.getTitle() + " updated");
		}

		public void actionPerformed(ActionEvent e) {
			Object b = e.getSource();

			if (b==button1) {
				ImagePlus imp = WindowManager.getCurrentImage();

				String metadata = imp.getStack().getSliceLabel(imp.getCurrentSlice());
				String dummy;
				byte[] red = new byte[256];
				byte[] gre = new byte[256];
				byte[] blu = new byte[256];

				StringTokenizer st = new StringTokenizer(metadata, "\n ");
				int tokens = st.countTokens(); // title + (256 * 3) 
				String[] strings = new String[tokens];
				dummy=st.nextToken();

				for(int i=0; i<256; i++){
					red[i]=(byte)(Integer.valueOf(st.nextToken()).intValue()&0xff);
					gre[i]=(byte)(Integer.valueOf(st.nextToken()).intValue()&0xff);
					blu[i]=(byte)(Integer.valueOf(st.nextToken()).intValue()&0xff);
				}

				if (list.getSelectedItem()!=null){
					IJ.selectWindow(list.getSelectedItem());
					//IJ.open(dir+metadata); // load LUT
					ImagePlus imp2 = WindowManager.getCurrentImage();
					ImageProcessor ip = WindowManager.getCurrentImage().getProcessor();
					ColorModel cm = new IndexColorModel(8, 256, red, gre, blu);
					ip.setColorModel(cm);
					if (imp2.getStackSize()>1)
						imp2.getStack().setColorModel(cm);
					imp2.updateAndDraw();
					//IJ.log(metadata);
				}
				else{
					IJ.showStatus("No image selected! Please select an image.");
				}
			}
		}
    } // CustomStackWindow inner class
} // Panel_Window class
